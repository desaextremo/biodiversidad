//Referencia a la lista de los departamentos
let deptos = document.querySelector("#deptos")
//Referencia a la lista de los reinos
let reinos = document.querySelector("#reinos")
//Referencia a la tabla de datos
let datos_consulta = document.querySelector("#datos_consulta")
//Referencia al boton
let boton_consultr = document.querySelector("#consultar")

//Inicialmente la tabla de datos esta oculta
datos_consulta.style.display="none"

//eventos del boton
boton_consultr.addEventListener("click",function(){
    procesar_consulta();
})

//funcion para el procesamiento de evento clic
//Recuperar datos, validar, y realziar la peticion
function procesar_consulta(){
    let departamento_seleccionado = deptos.value
    let reino_seleccionado = reinos.value

    alert("Departamento seleccionado " + departamento_seleccionado + "<br>Reino seleccionado: " + reino_seleccionado)
}
