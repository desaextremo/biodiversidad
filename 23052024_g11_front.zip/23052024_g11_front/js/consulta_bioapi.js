//referencia a select o lista desplegable de reinos
let reinos = document.querySelector("#reino")

//referencia a select o lista desplegable de departamentos
let departamentos = document.querySelector("#deptos")

//referencia a resultados
let resultados = document.querySelector("#resultados")

//referencia a boton
let consultar = document.querySelector("#consultar")

//inicialmente los resultados estan ocultos
resultados.style.display="none"

//procesar evento de click
consultar.addEventListener("click",function(){
    consultar_bioapi()
})

/*
    1 recupera el reino y departamento seleccionado
    2 utiliza axios para invocar al ws o API Biodiversidad
*/
function consultar_bioapi(){
    let reino_seleccionado = reinos.value
    let departamento_seleccionado = departamentos.value

    alert("Departamento " + departamento_seleccionado + " Reino: " + reino_seleccionado)
}